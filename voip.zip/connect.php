<?php

define("auth_id", "MAMGZKNZA0YJIZY2ZJMZ");
define("auth_token", "NWQ5NDVlMzdiOWUxNTQwZGJmYzkyNzc1MGZlZWE1");